# Hidden Leak or Just a High LADWP Bill? 9 Signs Your Los Angeles Home Is Losing Water

**Suggested URL slug:** `/blog/high-ladwp-bill-hidden-water-leak-los-angeles/`  
**Primary keyword:** leak detection Los Angeles  
**Secondary keywords:** high LADWP bill leak, slab leak Los Angeles, hidden water leak Los Angeles, water meter leak test  
**Meta title:** Hidden Water Leak in Los Angeles? 9 Warning Signs  
**Meta description:** High LADWP bill but no visible leak? Check these 9 signs of hidden water loss, from meter movement to warm floors and slab-leak clues.

---

A higher water bill can happen for innocent reasons: guests, irrigation, summer usage, a larger household or a rate change. But when the increase is sharp, unexplained and persistent, homeowners start asking the right question: **“Is water leaking somewhere I cannot see?”**

Hidden leaks can waste water for weeks before they create an obvious puddle. Some stay inside walls. Others run under floors or slabs. A toilet can leak silently. An irrigation line can fail outside while the house looks perfectly dry.

Here are nine signs worth checking before you dismiss the bill as a mystery.

## 1. The water meter moves when everything is off

This is one of the most useful homeowner observations.

Turn off faucets, washing machines, dishwashers, irrigation and other known water uses. Make sure toilets are not refilling. Then observe the water meter over a period of time.

If the leak indicator or meter reading changes while no water should be running, water may be flowing somewhere in the system.

Do not use this alone to decide where the leak is. Use it as evidence that further investigation is justified.

## 2. Your bill rises but your habits did not

One expensive month can be caused by unusual activity. A continuing increase without a lifestyle explanation deserves attention.

Compare usage across prior billing periods if the utility account makes that information available. LADWP provides customers with tools and account information that can help them review water consumption.

The useful signal is not simply “my bill is high.” It is **“my usage changed and I cannot explain why.”**

## 3. You hear water when nobody is using it

A faint hiss, trickle or running-water sound inside a wall can be an important clue, especially late at night when the house is quiet.

Toilets are common offenders, so check them first. A fill valve or flapper can cycle intermittently without drawing much attention.

If the sound appears to come from a wall or floor, professional leak detection may be appropriate.

## 4. A floor feels unexpectedly warm

In homes with hot-water piping below the slab, a hot-water leak can sometimes create an unusually warm area on the floor.

Warm flooring alone does not prove a slab leak. Sun exposure, HVAC ducts and appliances can also affect surface temperature. But a new persistent hot spot combined with increased water use or a running meter is worth investigating.

## 5. Paint, drywall or baseboards keep changing

Look for staining, bubbling paint, soft drywall, swelling baseboards, peeling finishes or recurring discoloration.

Water can travel along framing before it appears, which means the visible damage may not be directly below the source.

Do not assume that opening the wall at the stain will reveal the leak. A careful diagnosis can reduce unnecessary demolition.

## 6. You smell mustiness with no obvious source

Persistent moisture can create odors before you see significant damage.

A musty smell near a cabinet, wall, closet or flooring transition can indicate moisture that deserves inspection. The plumbing leak may be only one possible cause, but it should not be ignored if other water-loss signs are present.

## 7. Water pressure has changed

A major leak can affect pressure, although many pressure problems have other causes. If the change is sudden and occurs throughout the property, note when it started and whether it coincides with unexplained water use.

A pressure test and system inspection can help separate a leak from regulator, supply or fixture issues.

## 8. The yard has a wet or unusually green area

Not every hidden leak is indoors.

A damaged irrigation line, underground water service or exterior plumbing can saturate soil. Look for persistent wet spots, pooling, erosion or a patch of vegetation that suddenly looks much greener than the surrounding area.

Outdoor leaks can consume a surprising amount of water without creating any interior damage.

## 9. You keep “fixing” moisture but it comes back

Recurring damage is the biggest red flag of all.

If a wall has been patched twice, a cabinet keeps swelling, flooring repeatedly changes color or the same ceiling stain returns, stop treating the cosmetic symptom as the problem.

Find the source.

## What professional leak detection actually does

The goal of leak detection is not to promise zero opening of walls or floors. It is to **narrow the likely source before invasive work begins**.

Depending on the situation, plumbers may use pressure testing, acoustic equipment, thermal observations, isolation procedures, meter analysis and other methods to locate or confirm water loss.

The technique depends on whether the suspected leak is in a pressurized supply line, drain, fixture, irrigation system or another part of the property.

## Do not confuse a hidden leak with a slab leak

“Slab leak” is often used casually to describe any mysterious water problem. Technically, it generally refers to leaking piping located beneath or within a concrete slab foundation.

A high bill does not automatically mean a slab leak. Toilets, irrigation, water service lines and visible fixtures should also be considered.

Diagnosis matters because the repair options are completely different.

## What to do if you suspect a leak today

Start simple:

- Check toilets for continuous or intermittent running.
- Look under sinks and around appliances.
- Inspect the water-heater area.
- Review irrigation schedules and wet spots outside.
- Compare recent water usage with prior periods.
- Observe the meter when all known water use is off.

If the evidence still points to unexplained water flow, call a licensed Los Angeles plumber for leak detection.

The objective is not to tear into the house until someone finds water. It is to build enough evidence to locate the likely source and choose the least destructive repair approach that makes sense.

A high LADWP bill may turn out to have a simple explanation. But if usage has increased, the meter moves while the property is quiet, or moisture keeps appearing, the costliest choice is often doing nothing.
