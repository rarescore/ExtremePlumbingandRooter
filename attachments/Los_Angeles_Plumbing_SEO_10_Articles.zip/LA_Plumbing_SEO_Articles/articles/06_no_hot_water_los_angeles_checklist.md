# No Hot Water? The Los Angeles Water Heater Checklist to Use Before You Replace It

**Suggested URL slug:** `/blog/no-hot-water-los-angeles-checklist/`  
**Primary keyword:** water heater repair Los Angeles  
**Secondary keywords:** no hot water Los Angeles, water heater replacement Los Angeles, tankless water heater Los Angeles, water heater leaking  
**Meta title:** No Hot Water in Los Angeles? Repair-or-Replace Checklist  
**Meta description:** No hot water in Los Angeles? Use this practical checklist before replacing your heater, then learn when repair, replacement or tankless makes sense.

---

Few home problems change your morning faster than turning on the shower and getting cold water. The instinct is often immediate: **“The water heater is dead. I need a new one.”**

Sometimes that is true. Often, a no-hot-water call is caused by a specific failed component, fuel or electrical issue, control problem, or fixture condition that should be diagnosed before an entire heater is replaced.

Use this checklist to understand the problem before you make a large purchase.

## Step 1: Is there no hot water anywhere, or only at one fixture?

This is the fastest way to divide the problem.

If the kitchen has hot water but one shower does not, the water heater is probably not the first suspect. A shower valve, cartridge, anti-scald setting or fixture-specific problem may be involved.

If every fixture is cold, the water heater or its energy source moves much higher on the list.

That distinction can save a completely unnecessary replacement.

## Step 2: Is the water cold, lukewarm or running out too quickly?

These symptoms point in different directions.

**Completely cold water** may indicate that the heater is not operating at all.

**Lukewarm water** can involve thermostat settings, heating elements, burner problems, mixing issues or a heater that is struggling to recover.

**Hot water that runs out much faster than it used to** can indicate a capacity issue, component failure, sediment accumulation or changing household demand.

Tell the plumber exactly which symptom you have. “No hot water” is less useful than “it heats for five minutes and then goes cold.”

## Step 3: Look for water where it should not be

Check the area around the heater without touching unfamiliar controls or components.

Look for active leaking, rust streaks, dampness, corrosion at connections, water in the drain pan or signs that water has been present recently.

A leaking connection may be repairable. A tank leaking through its body is a very different situation and often makes replacement the practical path.

If water is actively spreading, control the water if you know how to do so safely and call for service.

## Step 4: Know whether your heater is gas, electric or tankless

The troubleshooting path depends on the equipment.

Electric tank heaters commonly use heating elements and thermostatic controls. Gas tank heaters use a burner and gas-control system. Tankless systems have sensors, flow requirements, ignition or electrical controls and often diagnostic codes.

If your tankless unit displays an error code, write it down or take a photo. Do not repeatedly reset a unit without understanding why it is faulting.

For any suspected gas leak, follow current gas-utility emergency guidance rather than trying to troubleshoot the equipment yourself.

## Step 5: How old is the water heater — and how has it behaved lately?

Age does not automatically mean replacement, but it changes the economic decision.

A relatively young heater with one replaceable failed component can be a strong repair candidate. An older tank with corrosion, repeated repairs and declining performance may not justify another expensive service call.

Ask the plumber to separate two questions:

1. **Can it be repaired?**
2. **Does repairing it make financial sense?**

Those are not always the same answer.

## Step 6: Is the problem really capacity?

A heater can be working properly and still feel inadequate if household demand has changed.

Maybe more people live in the home. Maybe a large soaking tub was added. Maybe showers overlap with laundry and dishwashing. Maybe a previous heater was replaced with a smaller unit.

If the problem is capacity, replacing a component will not solve it. The system needs to be sized around actual usage.

## Repair or replace? Use this decision framework

**Repair becomes more attractive when:**

- The tank itself is not leaking.
- The heater is reasonably young.
- The failed component is identifiable and replaceable.
- The system has otherwise been reliable.
- Repair cost is modest compared with replacement.

**Replacement becomes more attractive when:**

- The tank body is leaking.
- Corrosion is significant.
- Breakdowns are becoming frequent.
- The system no longer meets household demand.
- A major repair on an older heater would only postpone replacement briefly.

A written estimate should make the tradeoff visible.

## Should you switch to tankless while you are replacing it?

A water-heater failure often triggers the tankless question. Tankless systems can be excellent, but they should not be treated as a universal upgrade.

The installed cost can be affected by gas-line sizing, venting, electrical requirements, condensate routing, equipment location and the flow rate needed for the home. A direct tank-for-tank replacement may be simpler.

If you are interested in tankless, ask for a **complete conversion estimate**, not just the price of the appliance.

## Why diagnosis matters more than the brand sticker

Homeowners often search for the “best water heater.” Brand matters, but installation quality, sizing and system compatibility matter just as much.

An expensive heater that is undersized or poorly installed can perform worse than a properly selected, professionally installed standard model.

Before choosing equipment, understand the cause of the current failure and what the replacement must actually do.

## What to ask your Los Angeles plumber

Before approving work, ask:

- What failed?
- Is the tank itself leaking?
- What would repair cost and what would replacement cost?
- If repaired, what remaining issues should I expect?
- Is the current heater properly sized?
- Are permit or code-related upgrades part of the replacement scope?
- If considering tankless, what infrastructure changes are required?
- What warranty applies to equipment and labor?

The best water-heater decision is not “repair everything” or “replace everything.” It is the option that makes sense for the condition of the system and the needs of the household.

If your Los Angeles home has no hot water, start by determining whether the problem affects the whole house, document any leaks or error codes, and get a diagnosis before authorizing a replacement.
