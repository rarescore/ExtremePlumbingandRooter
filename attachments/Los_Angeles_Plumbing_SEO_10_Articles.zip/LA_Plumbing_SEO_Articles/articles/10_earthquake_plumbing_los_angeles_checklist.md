# Earthquake-Proof Your Plumbing: What Los Angeles Homeowners Forget Until It’s Too Late

**Suggested URL slug:** `/blog/earthquake-plumbing-los-angeles-checklist/`  
**Primary keyword:** earthquake plumbing Los Angeles  
**Secondary keywords:** earthquake gas shutoff valve Los Angeles, water heater strapping California, seismic gas valve Los Angeles, earthquake home plumbing checklist  
**Meta title:** Earthquake Plumbing Los Angeles: The Homeowner Checklist  
**Meta description:** Is your Los Angeles plumbing ready for an earthquake? Check water-heater restraint, shutoffs, gas safety, exposed piping and post-quake warning signs.

---

Los Angeles homeowners think about earthquake kits, flashlights and bottled water. Plumbing is easier to forget because it sits quietly in the background — until movement turns a rigid connection into a leak or a heavy water heater into a hazard.

No house can be made literally “earthquake-proof.” The practical goal is to **reduce avoidable risks, know how to shut systems down and recognize warning signs after shaking stops**.

Here is the plumbing-focused checklist worth reviewing before the next earthquake, not after it.

## 1. Make sure the water heater is properly restrained

A full tank water heater is heavy. During strong shaking, an unsecured or poorly restrained heater can move, damage water connections or create additional hazards.

California seismic-safety guidance addresses water-heater restraint, and local installation requirements should be followed for the specific property and equipment.

Homeowners should not treat a loose strap thrown around the tank as automatically sufficient. If you are unsure whether the restraint is correctly installed, have it inspected.

## 2. Know where the main water shutoff is

This is one of the simplest preparedness steps and one of the most useful.

If a supply pipe breaks after an earthquake, shutting off water quickly can reduce property damage. Find the main shutoff, make sure responsible adults know its location and ensure the area is accessible.

Do not wait until water is spreading through the house to discover that the valve is hidden behind storage or buried in landscaping.

## 3. Label important fixture shutoffs

In some emergencies you will not need to shut water to the entire home. A failed toilet supply, sink connection or appliance line may be isolated locally.

Know which valves serve toilets, sinks, washing machines and other water-using equipment. Older valves that have not moved in years can seize or fail, so accessibility alone does not guarantee they are serviceable.

If a valve looks badly corroded or leaks when touched, schedule replacement rather than experimenting during an emergency.

## 4. Understand gas safety before you need it

Natural-gas safety deserves special caution.

SoCalGas provides current guidance on earthquake shutoff valves, excess-flow valves and what customers should do if they suspect a gas leak. If you smell gas, hear escaping gas or observe signs of a leak, follow the utility’s emergency instructions and avoid actions that could create an ignition source.

Do not make “turn off the gas after every earthquake” your automatic rule. Utility guidance matters because unnecessary shutoff can create its own complications, and gas service that has been turned off at the meter should not be restored by the customer.

Keep the utility’s emergency contact information available.

## 5. Know what an earthquake gas shutoff valve actually does

Earthquake shutoff valves are designed to close gas flow when significant seismic motion is detected. Excess-flow valves work differently, responding to certain abnormal flow conditions.

They are not the same device and do not eliminate the need to respond appropriately if you smell gas.

If you are considering installation, use qualified professionals and follow current utility and local requirements for the specific system.

## 6. Inspect exposed piping and connections

Walk accessible areas such as garages, crawlspaces, utility rooms and around the water heater.

Look for unsupported runs, corrosion, strained connections or piping that appears vulnerable to movement. Flexible connectors and supports must be appropriate for the equipment and application; do not assume “flexible” automatically means “earthquake safe.”

A licensed plumber can identify obvious weaknesses and recommend corrections where appropriate.

## 7. Secure the area around plumbing equipment

Sometimes the plumbing survives the shaking but something else falls onto it.

Heavy storage shelves, tools or household items near a water heater can damage valves or connections during an earthquake. Keep access to shutoffs clear and avoid storing heavy objects where they could strike vulnerable plumbing equipment.

Preparedness includes the space around the system, not just the pipes themselves.

## 8. After an earthquake, use your senses before using fixtures

Once the shaking stops and it is safe to move, look and listen.

Do you hear water running when no fixture is on? Is there new water on the floor? Has a supply line pulled loose? Does a ceiling show fresh staining? Are drains behaving abnormally? Do you smell gas?

If you suspect a significant water leak, shut off the water if you can do so safely. If you suspect a gas leak, follow SoCalGas emergency guidance and move to a safe location.

Do not begin casually testing every faucet if you already see signs that a drainage system or sewer may have been damaged.

## 9. Check the water heater before assuming it is fine

Even if the heater remains upright, inspect the surrounding area for new leaks, displaced connections or visible damage.

If a gas-fired appliance appears damaged or you have any concern about gas safety, do not attempt improvised repairs or relighting procedures.

A professional inspection is a small price compared with guessing around fuel-burning equipment.

## 10. Create a plumbing emergency card

Keep a simple note somewhere accessible with:

- Main water shutoff location.
- Plumber’s phone number.
- Gas utility emergency contact.
- Water-heater type and location.
- Any special shutoff instructions for the property.
- Contact information for building management if applicable.

In a stressful moment, a clear checklist is more useful than trying to remember what you once read online.

## What homeowners should not do

Do not promise yourself that you will “figure out the valves” during an emergency. Do not force a stuck shutoff. Do not enter standing water near electrical hazards. Do not relight or restore gas service contrary to utility guidance. Do not assume a house is safe simply because no pipe is visibly broken.

Preparedness is mostly boring work done in advance — which is exactly why it works.

## A practical pre-earthquake plumbing inspection

If your Los Angeles home is older, has had multiple remodels, contains aging water-heater connections or has shutoffs you are not confident in, ask a licensed plumber for a focused preparedness inspection.

The goal is not to sell an imaginary “earthquake-proof” system. It is to identify obvious vulnerabilities, confirm you can isolate water when needed, review water-heater restraint and make sure you know what to do if a leak appears.

Earthquakes are unpredictable. Your response plan does not have to be.
