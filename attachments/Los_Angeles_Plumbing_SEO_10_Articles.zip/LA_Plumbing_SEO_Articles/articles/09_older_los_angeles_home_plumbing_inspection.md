# Buying an Older Los Angeles Home? Get This Plumbing Inspection Before You Close

**Suggested URL slug:** `/blog/older-los-angeles-home-plumbing-inspection/`  
**Primary keyword:** plumbing inspection Los Angeles  
**Secondary keywords:** sewer inspection Los Angeles, sewer camera inspection LA, older home plumbing Los Angeles, pre purchase plumbing inspection  
**Meta title:** Buying an Older LA Home? Get This Plumbing Inspection  
**Meta description:** Before closing on an older Los Angeles home, inspect the sewer, supply piping, water pressure, hidden leaks and water heater — not just the finishes.

---

Original tile, built-ins, mature landscaping and neighborhood character are some of the reasons buyers love older Los Angeles homes. The same age that gives a property charm can also mean decades of plumbing repairs, additions and materials hidden behind the walls.

A standard home inspection is valuable, but a general inspection may not answer the most expensive plumbing questions. Before closing, buyers should understand what they are purchasing below the sinks, inside the walls and under the yard.

Here is the plumbing inspection checklist that can save you from discovering a major problem after the keys are yours.

## 1. Camera the sewer when the risk justifies it

The sewer lateral is out of sight and can be expensive to repair. That makes it a strong candidate for pre-purchase investigation, especially in an older property or one surrounded by mature trees.

A sewer camera may reveal root intrusion, cracks, separated joints, offsets, corrosion, standing water or other conditions that deserve attention.

Ask the inspector or plumber to explain the footage rather than simply handing you a video file. You want to know what was seen, where it appears to be and whether it is a maintenance issue or a structural concern.

## 2. Identify visible supply-pipe materials

Older homes may have been partially repiped over time. One bathroom may have newer piping while another section remains original.

Look at accessible areas such as crawlspaces, garages, basements, water-heater connections and under sinks. The goal is to understand whether the home has one consistent plumbing system or a patchwork of generations.

No pipe material should be judged by age alone. Condition, installation quality and evidence of prior leaks matter.

## 3. Test water pressure — and ask whether it is stable

Very low pressure is frustrating. Excessively high pressure can stress fixtures, valves and appliances.

A pressure test provides a snapshot, but buyers should also ask whether the home has a pressure regulator and whether occupants have noticed fluctuations.

If multiple fixtures have weak flow, do not assume the city supply is the cause. Internal piping, valves, regulators or buildup can all influence performance.

## 4. Look for evidence of old leaks, not just active ones

Fresh paint can hide a stain. A dry cabinet can still show swelling or old water marks. Baseboards, drywall, vanity interiors, ceilings below bathrooms and flooring transitions may reveal a history that is not obvious at first glance.

Ask whether prior leak repairs are documented. A repaired leak is not automatically a problem; undocumented recurring water damage is more concerning.

## 5. Check every fixture under real use

Turn on showers and sinks. Flush toilets. Run more than one fixture at a time. Watch how quickly drains empty and whether toilets bubble or nearby drains gurgle.

A fixture can appear fine when tested alone but reveal a drainage or pressure issue when the system is under simultaneous use.

Look under sinks while water is running. Slow drips often become visible only when a drain or supply connection is active.

## 6. Evaluate the water heater as a system, not an appliance

Record the type, approximate age, capacity and visible condition of the water heater. Look at connections, drain pan arrangements where present, venting on gas equipment and signs of corrosion or leakage.

Ask whether the heater appears appropriately sized for the household you plan to have.

If you are considering tankless, do not assume the conversion is simple. Get a separate estimate for the infrastructure required.

## 7. Ask about shutoffs

A beautiful house becomes a bad experience quickly if a leaking fixture cannot be isolated.

Find the main water shutoff and accessible fixture shutoffs. Check whether they appear serviceable. In a multi-unit or converted property, determine which valves serve which areas.

This is not just inspection trivia. Knowing the shutoffs can reduce damage during a future emergency.

## 8. Pay attention to additions and remodels

Los Angeles homes are often renovated in stages. Bathrooms move. Kitchens expand. Laundry rooms appear in new locations. Accessory spaces are added or converted.

When plumbing has been altered substantially, ask for available permit and remodel documentation. The Los Angeles Department of Building and Safety provides the city’s permit infrastructure, and project-specific requirements can vary.

A buyer does not need to become a code expert. You do want to know whether major plumbing work has a documented history.

## 9. Verify the contractor if you are getting repair bids

California provides a public contractor-license lookup through the Contractors State License Board. If a plumbing inspection identifies significant work, verify the contractor before signing a repair agreement.

For a major sewer, repipe or water-heater project, licensing is a basic trust check — not the only one, but an important one.

## How to use inspection findings during the purchase

The purpose of an inspection is not to make every older home look scary. It is to convert uncertainty into information.

A camera may show a clean, serviceable sewer. Old piping may be functioning well. A water heater may have useful life remaining. Those are valuable findings too.

When problems are found, get a written scope and estimate. Distinguish between:

- **Immediate safety or active-leak issues.**
- **Near-term repairs.**
- **Maintenance items.**
- **Optional upgrades.**

That prevents a long inspection report from turning into one giant, undifferentiated fear list.

## The most expensive sentence in real estate: “We’ll deal with it later”

After closing, every plumbing issue becomes your decision and your budget.

A pre-purchase sewer camera, pressure test or focused plumbing inspection can cost far less than discovering a failed sewer lateral, hidden leak or inadequate hot-water system after move-in.

If you are buying an older Los Angeles home, ask a licensed plumber to inspect the systems that are difficult for a general walkthrough to evaluate. You do not need a perfect house. You need to know what is there, what condition it is in and what you may need to spend next.
