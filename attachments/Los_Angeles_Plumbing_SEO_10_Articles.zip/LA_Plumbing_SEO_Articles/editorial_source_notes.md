# Editorial Source Notes

Use these for fact-checking and updates before publication. They are not intended to appear as visible citations in every article.

- Google Business Profile local ranking guidance: relevance, distance and prominence.
- Google Ads Keyword Planner documentation: search volumes are averaged/rounded and influenced by date range and location settings.
- SoCalGas emergency preparedness and natural-gas shutoff guidance.
- SoCalGas earthquake and excess-flow valve guidance.
- California Contractors State License Board (CSLB) license lookup.
- Los Angeles Department of Building and Safety (LADBS) for permit/project requirements.
- LADWP account/water-use tools for customer consumption review.
- California seismic safety resources for water-heater restraint and preparedness.

Research also reviewed Los Angeles-area plumbing competitors and local homeowner discussions for qualitative search intent around drain-cleaning offers, recurring sewer issues, second opinions, pricing and trust.
